-- MiHealBot v0.3 - Aspecto y actualización de cada marco (vida, texto, recursos, curación, auras, rango)
local addonName, ns = ...

local PET_COLOR = { 0.6, 0.8, 0.3 }

-- Ejecuta una función protegida; guarda el primer error de cada etiqueta (ver /mhb debug)
local function Safe(tag, fn, ...)
    local ok, err = pcall(fn, ...)
    if not ok and not ns.errs[tag] then ns.errs[tag] = err end
end
ns.Safe = Safe

---------------------------------------------------------------------
-- Iconos de auras
---------------------------------------------------------------------
local function GetAuraIcon(f, kind, i)
    local icon = f.auras[kind][i]
    if icon then return icon end
    icon = CreateFrame("Frame", nil, f.overlay)
    icon:SetFrameLevel(f.overlay:GetFrameLevel() + 2)
    icon.border = icon:CreateTexture(nil, "BACKGROUND")
    icon.border:SetPoint("TOPLEFT", -1, 1)
    icon.border:SetPoint("BOTTOMRIGHT", 1, -1)
    icon.border:SetColorTexture(0, 0, 0, 1)
    icon.tex = icon:CreateTexture(nil, "ARTWORK")
    icon.tex:SetAllPoints()
    icon.tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    icon.cd = CreateFrame("Cooldown", nil, icon, "CooldownFrameTemplate")
    icon.cd:SetAllPoints()
    icon.cd:SetHideCountdownNumbers(true)
    if icon.cd.SetDrawEdge then icon.cd:SetDrawEdge(false) end
    icon.count = icon:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall")
    icon.count:SetPoint("BOTTOMRIGHT", 1, 0)
    icon:Hide()
    f.auras[kind][i] = icon
    return icon
end
ns.GetAuraIcon = GetAuraIcon

local GROW = {
    RIGHT = { "LEFT", "RIGHT", 1, 0 },
    LEFT = { "RIGHT", "LEFT", -1, 0 },
    UP = { "BOTTOM", "TOP", 0, 1 },
    DOWN = { "TOP", "BOTTOM", 0, -1 },
}

function ns.PlaceAuras(f)
    local o = ns.db.opts
    for _, kind in ipairs({ "buff", "debuff" }) do
        local c = o[kind]
        for i = 1, c.max do GetAuraIcon(f, kind, i) end
        local list = f.auras[kind]
        local g = GROW[c.grow] or GROW.RIGHT
        for i = 1, #list do
            local icon = list[i]
            icon:SetSize(c.size, c.size)
            icon:ClearAllPoints()
            if i > c.max then
                icon:Hide()
            elseif i == 1 then
                icon:SetPoint(c.anchor, f, c.anchor, c.x, c.y)
            else
                icon:SetPoint(g[1], list[i - 1], g[2], g[3], g[4])
            end
        end
    end
end

---------------------------------------------------------------------
-- Construcción y estilo
---------------------------------------------------------------------
function ns.BuildVisual(f)
    local tex = ns.TEXTURES[1]
    f.bg = f:CreateTexture(nil, "BACKGROUND")
    f.bg:SetAllPoints()
    f.bg:SetColorTexture(0, 0, 0, 0.6)

    f.hp = CreateFrame("StatusBar", nil, f)
    f.hp:SetStatusBarTexture(tex)
    f.hp:SetMinMaxValues(0, 1)
    f.hp:SetValue(1)
    if f.hp.SetClipsChildren then f.hp:SetClipsChildren(true) end

    f.heal = CreateFrame("StatusBar", nil, f.hp)
    f.heal:SetStatusBarTexture(tex)
    f.heal:SetStatusBarColor(0.3, 1, 0.5, 0.6)
    f.heal:SetMinMaxValues(0, 1)
    f.heal:SetValue(0)

    f.power = CreateFrame("StatusBar", nil, f)
    f.power:SetStatusBarTexture(tex)
    f.power:SetMinMaxValues(0, 1)
    f.power:SetValue(1)

    f.overlay = CreateFrame("Frame", nil, f)
    f.overlay:SetAllPoints()
    f.overlay:SetFrameLevel(f:GetFrameLevel() + 10)

    f.nameText = f.overlay:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.nameText:SetWordWrap(false)
    f.numText = f.overlay:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.pctText = f.overlay:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")

    f.auras = { buff = {}, debuff = {} }
end

function ns.LayoutVisual(f)
    local o = ns.db.opts
    local ph = o.showPower and o.powerHeight or 0

    f.hp:ClearAllPoints()
    f.power:ClearAllPoints()
    if o.showPower then
        f.power:Show()
        f.power:SetHeight(ph)
        if o.powerPos == "T" then
            f.power:SetPoint("TOPLEFT", 1, -1)
            f.power:SetPoint("TOPRIGHT", -1, -1)
            f.hp:SetPoint("TOPLEFT", 1, -(ph + 2))
            f.hp:SetPoint("BOTTOMRIGHT", -1, 1)
        else
            f.power:SetPoint("BOTTOMLEFT", 1, 1)
            f.power:SetPoint("BOTTOMRIGHT", -1, 1)
            f.hp:SetPoint("TOPLEFT", 1, -1)
            f.hp:SetPoint("BOTTOMRIGHT", -1, ph + 2)
        end
    else
        f.power:Hide()
        f.hp:SetPoint("TOPLEFT", 1, -1)
        f.hp:SetPoint("BOTTOMRIGHT", -1, 1)
    end

    -- barra de curación prevista: arranca donde acaba la vida actual
    local tex = f.hp:GetStatusBarTexture()
    f.heal:ClearAllPoints()
    f.heal:SetPoint("TOPLEFT", tex, "TOPRIGHT")
    f.heal:SetPoint("BOTTOMLEFT", tex, "BOTTOMRIGHT")
    f.heal:SetWidth(math.max(1, o.width - 2))

    -- textos
    local up = (o.textPos == "T")
    f.nameText:ClearAllPoints()
    f.nameText:SetPoint(up and "BOTTOM" or "TOP", f.hp, up and "BOTTOM" or "TOP", 0, up and 3 or -3)
    f.numText:ClearAllPoints()
    f.pctText:ClearAllPoints()
    if o.textPos == "T" then
        f.numText:SetPoint("TOPLEFT", f.hp, "TOPLEFT", 3, -3)
        f.pctText:SetPoint("TOPRIGHT", f.hp, "TOPRIGHT", -3, -3)
    elseif o.textPos == "C" then
        f.numText:SetPoint("CENTER", f.hp, "CENTER", -o.width / 4, -4)
        f.pctText:SetPoint("CENTER", f.hp, "CENTER", o.width / 4, -4)
    else
        f.numText:SetPoint("BOTTOMLEFT", f.hp, "BOTTOMLEFT", 3, 3)
        f.pctText:SetPoint("BOTTOMRIGHT", f.hp, "BOTTOMRIGHT", -3, 3)
    end
    local m = o.healthText
    f.numText:SetShown(m == "num" or m == "both")
    f.pctText:SetShown(m == "pct" or m == "both")

    ns.PlaceAuras(f)
end

function ns.StyleFrame(f)
    local o = ns.db.opts
    if not (InCombatLockdown() and f:IsProtected()) then
        f:SetSize(o.width, o.height)
    end
    f.bg:SetColorTexture(0, 0, 0, o.bgAlpha)
    local tex = ns.TEXTURES[o.texture] or ns.TEXTURES[1]
    f.hp:SetStatusBarTexture(tex)
    f.heal:SetStatusBarTexture(tex)
    f.heal:SetStatusBarColor(0.3, 1, 0.5, 0.6)
    f.power:SetStatusBarTexture(tex)

    local font = STANDARD_TEXT_FONT
    f.nameText:SetFont(font, o.fontSize, "OUTLINE")
    f.nameText:SetWidth(math.max(10, o.width - 4))
    f.nameText:SetShown(o.showName)
    local small = math.max(7, o.fontSize - 1)
    f.numText:SetFont(font, small, "OUTLINE")
    f.pctText:SetFont(font, small, "OUTLINE")
    ns.LayoutVisual(f)
end

function ns.ColorBar(f, class)
    local c = ns.db.opts.classColor and class and RAID_CLASS_COLORS[class]
    if c then
        f.hp:SetStatusBarColor(c.r, c.g, c.b)
    else
        f.hp:SetStatusBarColor(0.1, 0.7, 0.2)
    end
end

---------------------------------------------------------------------
-- Actualizaciones
---------------------------------------------------------------------
local function ShortNum(n)
    if n >= 1000000 then return string.format("%.1fM", n / 1000000)
    elseif n >= 1000 then return string.format("%.1fk", n / 1000) end
    return tostring(math.floor(n))
end

local function UpdateName(f, unit)
    f.nameText:SetText(UnitName(unit))
end

local function UpdateColor(f, unit)
    if unit:find("pet") then
        f.hp:SetStatusBarColor(PET_COLOR[1], PET_COLOR[2], PET_COLOR[3])
    else
        local _, class = UnitClass(unit)
        ns.ColorBar(f, class)
    end
end

local function UpdateHealthText(f, unit)
    local m = ns.db.opts.healthText
    if m == "none" then return end
    -- 1) camino normal (valores numéricos normales)
    local ok = pcall(function()
        local hp, mx = UnitHealth(unit), UnitHealthMax(unit)
        local pct = (mx > 0) and math.floor(hp / mx * 100 + 0.5) or 0
        f.numText:SetText(ShortNum(hp))
        f.pctText:SetText(pct .. "%")
    end)
    if ok then return end
    -- 2) camino alternativo (valores restringidos en combate)
    pcall(function()
        if AbbreviateNumbers then f.numText:SetText(AbbreviateNumbers(UnitHealth(unit))) end
    end)
    pcall(function()
        if UnitHealthPercent then
            local scale = CurveConstants and CurveConstants.ScaleTo100
            f.pctText:SetFormattedText("%d%%", UnitHealthPercent(unit, true, scale))
        end
    end)
end

local function GetIncoming(unit)
    if CreateUnitHealPredictionCalculator and UnitGetDetailedHealPrediction then
        ns.calc = ns.calc or CreateUnitHealPredictionCalculator()
        UnitGetDetailedHealPrediction(unit, "player", ns.calc)
        local v = ns.calc:GetIncomingHeals()
        if v then return v end
    end
    if UnitGetIncomingHeals then
        return UnitGetIncomingHeals(unit, "player")
    end
end

local function UpdateHeal(f, unit)
    if not ns.db.opts.showHealPred then
        f.heal:Hide()
        return
    end
    local incoming = GetIncoming(unit)
    f.heal:SetMinMaxValues(0, UnitHealthMax(unit))
    f.heal:SetValue(incoming or 0)
    f.heal:Show()
end

local function UpdateHealth(f, unit)
    f.hp:SetMinMaxValues(0, UnitHealthMax(unit))
    f.hp:SetValue(UnitHealth(unit))
    Safe("textoVida", UpdateHealthText, f, unit)
    Safe("curacionPrevista", UpdateHeal, f, unit)
end

local function UpdatePower(f, unit)
    if not ns.db.opts.showPower then return end
    local ptype, token = UnitPowerType(unit)
    local c = (token and PowerBarColor[token]) or PowerBarColor[ptype] or { r = 0.2, g = 0.4, b = 0.9 }
    f.power:SetStatusBarColor(c.r, c.g, c.b)
    f.power:SetMinMaxValues(0, UnitPowerMax(unit, ptype))
    f.power:SetValue(UnitPower(unit, ptype))
end

-- Filtros de auras (listas separadas por comas, nombres o IDs)
local function ParseList(str)
    if not str or strtrim(str) == "" then return nil end
    local set, any = {}, false
    for item in string.gmatch(str, "[^,;]+") do
        item = strtrim(item)
        if item ~= "" then
            set[tonumber(item) or strlower(item)] = true
            any = true
        end
    end
    return any and set or nil
end

local function GetSets(kind)
    local c = ns.db.opts[kind]
    local cache = ns.auraSets[kind]
    if not cache or cache.w ~= c.white or cache.b ~= c.black then
        cache = { w = c.white, b = c.black, white = ParseList(c.white), black = ParseList(c.black) }
        ns.auraSets[kind] = cache
    end
    return cache.white, cache.black
end

local function PassesLists(data, white, black)
    if not white and not black then return true end
    local ok, pass = pcall(function()
        local nm = data.name and strlower(data.name)
        local id = data.spellId
        if black and (black[nm] or black[id]) then return false end
        if white and not (white[nm] or white[id]) then return false end
        return true
    end)
    if not ok then return true end
    return pass
end

local function SetupIcon(icon, unit, data, isDebuff)
    icon.tex:SetTexture(data.icon)
    pcall(function()
        local dur = C_UnitAuras.GetAuraDuration and C_UnitAuras.GetAuraDuration(unit, data.auraInstanceID)
        if dur and icon.cd.SetCooldownFromDurationObject then
            icon.cd:SetCooldownFromDurationObject(dur)
        elseif data.duration and data.duration > 0 then
            icon.cd:SetCooldown(data.expirationTime - data.duration, data.duration)
        else
            icon.cd:Clear()
        end
    end)
    pcall(function()
        if C_UnitAuras.GetAuraApplicationDisplayCount then
            icon.count:SetText(C_UnitAuras.GetAuraApplicationDisplayCount(unit, data.auraInstanceID, 2))
        elseif data.applications and data.applications > 1 then
            icon.count:SetText(data.applications)
        else
            icon.count:SetText("")
        end
    end)
    local r, g, b = 0, 0, 0
    if isDebuff then
        pcall(function()
            local col = data.dispelName and DebuffTypeColor and DebuffTypeColor[data.dispelName]
            if col then r, g, b = col.r, col.g, col.b end
        end)
    end
    icon.border:SetColorTexture(r, g, b, 1)
    icon:Show()
end

local function UpdateAuras(f, unit)
    if not (C_UnitAuras and C_UnitAuras.GetAuraDataByIndex) then return end
    local o = ns.db.opts
    for _, kind in ipairs({ "buff", "debuff" }) do
        local c = o[kind]
        local list = f.auras[kind]
        local shown = 0
        if c.show then
            local isDebuff = (kind == "debuff")
            local filter = isDebuff and "HARMFUL" or "HELPFUL"
            if c.only then filter = filter .. (isDebuff and "|RAID" or "|PLAYER") end
            local white, black = GetSets(kind)
            local i = 1
            while shown < c.max and i <= 40 do
                local data = C_UnitAuras.GetAuraDataByIndex(unit, i, filter)
                if not data then break end
                if PassesLists(data, white, black) then
                    shown = shown + 1
                    SetupIcon(GetAuraIcon(f, kind, shown), unit, data, isDebuff)
                end
                i = i + 1
            end
        end
        for j = shown + 1, #list do list[j]:Hide() end
    end
end

local function UpdateRange(f, unit)
    local o = ns.db.opts
    if not unit then return end
    if not o.rangeFade then
        f:SetAlpha(1)
        return
    end
    local a = o.rangeAlpha
    local spell = o.rangeSpell or ""
    -- 1) camino normal
    local ok = pcall(function()
        local r
        if UnitIsUnit(unit, "player") then
            r = true
        elseif not UnitIsConnected(unit) then
            r = false
        else
            if spell ~= "" then
                if C_Spell and C_Spell.IsSpellInRange then
                    r = C_Spell.IsSpellInRange(spell, unit)
                elseif IsSpellInRange then
                    local x = IsSpellInRange(spell, unit)
                    if x == 1 then r = true elseif x == 0 then r = false end
                end
            end
            if r == nil then
                local inR, checked = UnitInRange(unit)
                if checked == false then r = true else r = inR end
            end
        end
        f:SetAlpha(r == false and a or 1)
    end)
    if ok then return end
    -- 2) camino alternativo (booleanos restringidos)
    if f.SetAlphaFromBoolean then
        pcall(function()
            local r2
            if spell ~= "" and C_Spell and C_Spell.IsSpellInRange then
                r2 = C_Spell.IsSpellInRange(spell, unit)
            else
                r2 = UnitInRange(unit)
            end
            f:SetAlphaFromBoolean(r2, 1, a)
        end)
    end
end

local function UpdateAll(f)
    local unit = f:GetAttribute("unit")
    if not unit or not UnitExists(unit) then return end
    Safe("nombre", UpdateName, f, unit)
    Safe("color", UpdateColor, f, unit)
    Safe("vida", UpdateHealth, f, unit)
    Safe("recurso", UpdatePower, f, unit)
    Safe("auras", UpdateAuras, f, unit)
    Safe("rango", UpdateRange, f, unit)
end
ns.UpdateButton = UpdateAll

local HANDLERS = {
    UNIT_HEALTH = function(f, u) Safe("vida", UpdateHealth, f, u) end,
    UNIT_MAXHEALTH = function(f, u) Safe("vida", UpdateHealth, f, u) end,
    UNIT_HEAL_PREDICTION = function(f, u) Safe("curacionPrevista", UpdateHeal, f, u) end,
    UNIT_POWER_UPDATE = function(f, u) Safe("recurso", UpdatePower, f, u) end,
    UNIT_MAXPOWER = function(f, u) Safe("recurso", UpdatePower, f, u) end,
    UNIT_DISPLAYPOWER = function(f, u) Safe("recurso", UpdatePower, f, u) end,
    UNIT_AURA = function(f, u) Safe("auras", UpdateAuras, f, u) end,
    UNIT_NAME_UPDATE = function(f, u) Safe("nombre", UpdateName, f, u) end,
    UNIT_CONNECTION = function(f, u) Safe("rango", UpdateRange, f, u) end,
}

local function OnEvent(self, event)
    local unit = self:GetAttribute("unit")
    if not unit then return end
    local h = HANDLERS[event]
    if h then h(self, unit) end
end

local function OnAttributeChanged(self, name, value)
    if name ~= "unit" or not value then return end
    self:UnregisterAllEvents()
    for event in pairs(HANDLERS) do
        pcall(self.RegisterUnitEvent, self, event, value)
    end
    UpdateAll(self)
end

function MiHealBot_UnitButton_OnLoad(self)
    self:RegisterForClicks("AnyUp")
    ns.BuildVisual(self)
    ns.StyleFrame(self)

    self:HookScript("OnAttributeChanged", OnAttributeChanged)
    self:SetScript("OnEvent", OnEvent)
    self:HookScript("OnShow", UpdateAll)

    ns.buttons[self] = true
    if InCombatLockdown() then
        ns.pendingApply = true
    else
        ns.ApplyBindings(self)
    end
end

-- Atenuado por rango: se comprueba 4 veces por segundo
local driver = CreateFrame("Frame")
local acc = 0
driver:SetScript("OnUpdate", function(_, elapsed)
    acc = acc + elapsed
    if acc < 0.25 then return end
    acc = 0
    if not ns.db then return end
    for f in pairs(ns.buttons) do
        if f:IsShown() then
            Safe("rango", UpdateRange, f, f:GetAttribute("unit"))
        end
    end
end)
