-- MiHealBot v0.3 - Botón del minimapa (hoja verde, icono de Toque de vida)
local addonName, ns = ...

local btn

local function IconTexture()
    local t = C_Spell and C_Spell.GetSpellTexture and C_Spell.GetSpellTexture(33763) -- Toque de vida
    return t or "Interface\\Icons\\INV_Misc_Herb_Felblossom"
end

local function UpdatePosition()
    local a = math.rad(ns.db.minimapAngle or 200)
    local r = Minimap:GetWidth() / 2 + 5
    btn:ClearAllPoints()
    btn:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
end

local function OnDragUpdate()
    local mx, my = Minimap:GetCenter()
    local cx, cy = GetCursorPosition()
    local s = Minimap:GetEffectiveScale()
    cx, cy = cx / s, cy / s
    local atan = math.atan2 or math.atan
    ns.db.minimapAngle = math.deg(atan(cy - my, cx - mx))
    UpdatePosition()
end

local function CreateButton()
    btn = CreateFrame("Button", "MiHealBotMinimapButton", Minimap)
    btn:SetSize(32, 32)
    btn:SetFrameStrata("MEDIUM")
    btn:SetFrameLevel(8)
    btn:RegisterForClicks("AnyUp")
    btn:RegisterForDrag("LeftButton")

    local bg = btn:CreateTexture(nil, "BACKGROUND")
    bg:SetSize(20, 20)
    bg:SetPoint("TOPLEFT", 7, -5)
    bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")

    local icon = btn:CreateTexture(nil, "ARTWORK")
    icon:SetSize(18, 18)
    icon:SetPoint("TOPLEFT", 7, -6)
    icon:SetTexture(IconTexture())
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local border = btn:CreateTexture(nil, "OVERLAY")
    border:SetSize(54, 54)
    border:SetPoint("TOPLEFT")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")

    local hl = btn:CreateTexture(nil, "HIGHLIGHT")
    hl:SetSize(24, 24)
    hl:SetPoint("CENTER")
    hl:SetColorTexture(1, 1, 1, 0.2)

    btn:SetScript("OnClick", function(_, button)
        if button == "RightButton" then
            ns.TogglePreview()
        else
            ns.ToggleOptions()
        end
    end)
    btn:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", OnDragUpdate)
    end)
    btn:SetScript("OnDragStop", function(self)
        self:SetScript("OnUpdate", nil)
    end)
    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("MiHealBot")
        GameTooltip:AddLine("Clic izquierdo: opciones", 1, 1, 1)
        GameTooltip:AddLine("Clic derecho: vista previa", 1, 1, 1)
        GameTooltip:AddLine("Arrastrar: mover el botón", 1, 1, 1)
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    UpdatePosition()
end

function ns.UpdateMinimap()
    if not ns.db then return end
    if not btn then CreateButton() end
    btn:SetShown(ns.db.opts.showMinimap)
end

local init = CreateFrame("Frame")
init:RegisterEvent("PLAYER_LOGIN")
init:SetScript("OnEvent", function()
    pcall(ns.UpdateMinimap)
end)
